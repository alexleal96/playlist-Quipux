<template>
    <div>
        <h1>HOLI 😊</h1>
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>